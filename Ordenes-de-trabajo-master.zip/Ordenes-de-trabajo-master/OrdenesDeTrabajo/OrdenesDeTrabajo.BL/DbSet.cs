﻿namespace OrdenesDeTrabajo.BL
{
    public class DbSet<T1, T2>
    {
    }
}