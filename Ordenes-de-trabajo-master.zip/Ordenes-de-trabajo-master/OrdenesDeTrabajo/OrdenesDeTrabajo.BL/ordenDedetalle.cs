﻿namespace OrdenesDeTrabajo.BL
{
    internal class ordenDedetalle<T>
    {
    }
}